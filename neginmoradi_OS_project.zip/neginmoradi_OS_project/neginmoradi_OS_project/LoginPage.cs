﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace neginmoradi_OS_project
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
            //attach event handlers for button clicks
            EmployeeRegistrationPage.Click += EmployeeRegistrationPage_Click;
            CustomerRegistrationPage.Click += CustomerRegistrationPage_Click;
        }

        private void EmployeeRegistrationPage_Click(object sender, EventArgs e)
        {
            EmployeeRegistration employeeForm = new EmployeeRegistration();
            employeeForm.Show(); //show the Employee registration form
            this.Hide(); //hide the Main form
        }

        private void CustomerRegistrationPage_Click(object sender, EventArgs e)
        {
            CustomerRegistration customerForm = new CustomerRegistration();
            customerForm.Show(); //show the Customer registration form
            this.Hide(); //hide the Main form
        }
    }
}
