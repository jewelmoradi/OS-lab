﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace neginmoradi_OS_project
{
    public partial class NewTicket : Form
    {
        public NewTicket()
        {
            InitializeComponent();
        }

        private void NewTicket_Load(object sender, EventArgs e)
        {

        }
    }
}
