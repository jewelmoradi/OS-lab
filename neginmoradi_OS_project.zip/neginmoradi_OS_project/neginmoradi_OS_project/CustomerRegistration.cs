﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace neginmoradi_OS_project
{
    public partial class CustomerRegistration : Form
    {
        public CustomerRegistration()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void CustomerRegistration_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            string lastName = textBox2.Text;
            string id = textBox3.Text;
            string email = textBox4.Text;
            DateTime dateOfBirth = DateTime.Parse(textBox5.Text);
            string city = textBox6.Text;
            string country = textBox7.Text;
            int passportID = int.Parse(textBox8.Text); // Assuming passportID is an integer
            string phoneNumber = textBox9.Text;

            SaveCustomerData(firstName, lastName, id, email, dateOfBirth, city, country, passportID, phoneNumber);
        }
        private void SaveCustomerData(string firstName, string lastName, string id, string email, DateTime dateOfBirth, string city, string country, int passportID, string phoneNumber)
        {
            string connectionString = "DESKTOP-L7M8IM0\\HP";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Customer (FirstName, LastName, CustomerID, Email, DateOfBirth, City, Country, PhoneNumber) VALUES (@FirstName, @LastName, @ID, @Email, @DateOfBirth, @City, @Country, @PassportID, @PhoneNumber)";

                using (SqlCommand command = new SqlCommand(query, connection))
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@CustomerID", id);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
                    command.Parameters.AddWithValue("@City", city);
                    command.Parameters.AddWithValue("@Country", country);
                    command.Parameters.AddWithValue("@PassportID", passportID);
                    command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    command.ExecuteNonQuery();
            }
        }
    }
}  

