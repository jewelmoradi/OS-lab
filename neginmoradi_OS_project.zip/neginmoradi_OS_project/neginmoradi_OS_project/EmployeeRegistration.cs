﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace neginmoradi_OS_project
{
    public partial class EmployeeRegistration : Form
    {
        // Declare TextBox controls at the class level
        private TextBox txtId;
        private TextBox txtName;
        private TextBox txtEmail;
        public EmployeeRegistration()
        {
            InitializeComponent();
        }

        private void EmployeeRegistration_Load(object sender, EventArgs e)
        {

        }

        //event handler for Save button
        private void EmployeeRegistration_Click(object sender, EventArgs e)
        {
            // Access values from TextBox controls
            string email = txtEmail.Text;
            string employeeID = txtId.Text;
            string firstName = txtName.Text;
            string lastName = txtName.Text;

            DateTime dateOfBirth = DateTime.Today; // Set the default value or update as needed
            int phoneNumber = 0; // Set the default value or update as needed
            string position = "Employee"; // Set the default value or update as needed

            string departmentName = "Default Department"; // Set the default value or update as needed
            int departmentId = GetDepartmentId(departmentName);

            string supervisorIDString = "SupervisorEmployeeID"; // Retrieve the supervisor's employee ID from the form
            int supervisorID = GetSupervisorID(supervisorIDString);

            SaveEmployeeData(employeeID, firstName, lastName, dateOfBirth, email, phoneNumber, position, departmentId, supervisorID);
        }

        public void SaveEmployeeData(string employeeID, string firstName, string lastName, DateTime dateOfBirth, string email, int phoneNumber, string position, int departmentId, int supervisorID)
        {
            string connectionString = "DESKTOP-L7M8IM0\\HP";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Employee (EmployeeID, FirstName, LastName, DateOfBirth, Email, PhoneNumber, Position, Department, SupervisorID) VALUES (@EmployeeID, @FirstName, @LastName, @DateOfBirth, @Email, @PhoneNumber, @Position, @DepartmentId, @SupervisorID)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeID", employeeID);
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    command.Parameters.AddWithValue("@Position", position);
                    command.Parameters.AddWithValue("@DepartmentID", departmentId);
                    command.Parameters.AddWithValue("@SupervisorID", supervisorID);
                    command.ExecuteNonQuery();
                }
            }
        }

        private int GetDepartmentId(string departmentName)
        {
            string connectionString = "DESKTOP-L7M8IM0\\HP";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT DepartmentId FROM Department WHERE DepartmentName = @DepartmentName";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DepartmentName", departmentName);
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        private int GetSupervisorID(string supervisorEmployeeID)
        {
            string connectionString = "Your Connection String Here";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT EmployeeID FROM Employee WHERE EmployeeID = @SupervisorEmployeeID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupervisorEmployeeID", supervisorEmployeeID);
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            return Convert.ToInt32(result);
                        }
                        else
                        {
                            // Handle case where supervisor is not found
                            return -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return -1;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string firstname = textBox1.Text;
            string lastname = textBox2.Text;
            string id = textBox3.Text;
            string email = textBox4.Text;
            string dob = textBox5.Text;
            string supervisorID = textBox6.Text;
            string phoneNumber = textBox9.Text;

            firstname = "Maryam";
            lastname = "Ahmadi";
            id = "201";
            email = "maryahmadi@gmail.com";
            dob = "2003/06/05";
            supervisorID = "205";
            phoneNumber = "09176543897";
        }
    }
}
